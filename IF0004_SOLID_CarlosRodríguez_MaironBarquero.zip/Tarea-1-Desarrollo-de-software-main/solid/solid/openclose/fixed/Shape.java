package solid.openclose.fixed;

public abstract class Shape {
    
    public abstract double calculateArea();
}
