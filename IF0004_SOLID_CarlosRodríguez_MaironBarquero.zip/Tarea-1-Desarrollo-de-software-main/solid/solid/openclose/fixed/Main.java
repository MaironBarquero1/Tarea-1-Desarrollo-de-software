package solid.openclose.fixed;

import java.util.List;

public class Main {
    
    public static void main(String[] args) {
        
        Circle circle = new Circle(4);
        Rectangle rectangle = new Rectangle(8, 4);
        List<Shape> shapes = List.of(circle, rectangle);
        ShapeCalculatorOriginal shapeCalculator = new ShapeCalculatorOriginal(); 

        double totalArea = shapeCalculator.calculateTotalArea(shapes);
        System.out.println("Total Area: " + totalArea);

    }
}
