package fixed;

public class GasolineEngine implements Engine{
    
    public void Start() 
    {
        System.out.println("Gasoline engine started");
    }
}
