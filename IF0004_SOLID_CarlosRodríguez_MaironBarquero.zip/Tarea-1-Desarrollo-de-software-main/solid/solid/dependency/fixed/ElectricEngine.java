package fixed;

public class ElectricEngine implements Engine 
{

    @Override
    public void Start() 
    {
        System.out.println("Electric engine started");
    }
}
