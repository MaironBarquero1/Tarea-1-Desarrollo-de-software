package fixed;

public class Main {
    public static void main(String[] args) {

        Car car1 = new Car(new ElectricEngine());
        car1.start();

        Car car2 = new Car(new GasolineEngine());
        car2.start();
    }
}
