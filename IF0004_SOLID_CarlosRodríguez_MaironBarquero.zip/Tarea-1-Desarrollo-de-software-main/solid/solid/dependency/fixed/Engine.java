package fixed;

public interface Engine {
    
    public void Start();
}
