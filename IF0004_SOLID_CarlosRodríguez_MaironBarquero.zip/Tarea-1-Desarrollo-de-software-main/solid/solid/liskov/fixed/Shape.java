package solid.liskov.fixed;

public interface Shape {

    int calculate_area();
    
}
