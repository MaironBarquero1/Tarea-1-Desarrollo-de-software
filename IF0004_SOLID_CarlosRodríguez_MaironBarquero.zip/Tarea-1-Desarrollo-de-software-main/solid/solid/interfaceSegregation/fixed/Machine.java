package solid.interfaceSegregation.fixed;

public interface Machine {

    void work();

    void power_on();

    void power_off();
    
}
