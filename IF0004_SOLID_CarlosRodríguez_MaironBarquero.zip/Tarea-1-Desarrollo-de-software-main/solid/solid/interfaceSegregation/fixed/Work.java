package solid.interfaceSegregation.fixed;

public interface Work {
    
    void work();

}
