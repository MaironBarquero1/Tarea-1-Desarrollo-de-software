package solid.interfaceSegregation.fixed;

public interface Human {

    void eat();

    void sleep();
    
}
